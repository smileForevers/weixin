# netmusic-app
仿网易云音乐APP的微信小程序

目前有得页面性能较差，代码待优化，有的不知道是不是微信api的bug或者编辑器的，头疼


 [动图演示地址：](http://7vik7b.com1.z0.glb.clouddn.com/20161212_112210.gif)
 
 
<image src="http://7vik7b.com1.z0.glb.clouddn.com/20161212_112210.gif"/>
 
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4271.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4279.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4274.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4272.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4276.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4277.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4275.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4273.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4278.PNG"/>

##目前实现功能

1. 用户歌单
2. 歌单详情
3. FM
4. 音乐播放（暂停，上下一首，歌词）
5. 评论显示
6. MV
7. 专辑页
8. 歌手页

##TODO

* 登录
* 歌曲喜欢,FM trash
* 增加评论，评论点赞等
* 歌手详情
* 歌词翻译
* DJ
* 收藏歌单，收藏单曲



#####主体登录功能没有实现，登录方法已经有，希望有会nodejs的小伙伴得空帮忙，需要后台node代码的可私信我我
